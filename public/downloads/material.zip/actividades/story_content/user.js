function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Bld7yqh28q":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

